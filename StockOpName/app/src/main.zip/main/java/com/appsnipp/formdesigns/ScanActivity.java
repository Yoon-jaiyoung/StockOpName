package com.appsnipp.formdesigns;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TableRow.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

public class ScanActivity extends Activity {
    String intent_factory;
    String intent_id;
    String intent_location;
    EditText etBarcode;
    String nowDate;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    int count;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan);
        setCount(0);

        long now = System.currentTimeMillis(); // 현재시간 받아오기
        Date date = new Date(now); // Date 객체 생성
        SimpleDateFormat sdf_date = new SimpleDateFormat("MMdd");
        nowDate = sdf_date.format(date);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        intent_factory = intent.getStringExtra("intent_factory");
        intent_id = intent.getStringExtra("intent_id");
        intent_location = intent.getStringExtra("intent_location");
        // Capture the layout's TextView and set the string as its text
        TextView tvFac = findViewById(R.id.tvFac);
        TextView tvLoc = findViewById(R.id.tvLoc);
        TextView tvID = findViewById(R.id.tvID);
        TextView tvDate = findViewById(R.id.tvDate);
        tvFac.setText(intent_factory);
        tvLoc.setText(intent_location);
        tvID.setText(intent_id);
        tvDate.setText(nowDate);
        etBarcode = findViewById(R.id.etBarcode);
        try {
            readTxt();
        } catch (IOException e) {
            e.printStackTrace();
        }

        final InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        etBarcode.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                //Enter key Action
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    try {
                        setCount(getCount()+1);
                        saveInTxt(intent_factory,intent_id,intent_location,etBarcode.getText().toString(),Integer.toString(getCount()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    try {
                        readTxt();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS);
                    etBarcode.setText("");
                    etBarcode.requestFocus();
                    return true;
                }
                return false;
            }
        });

    }

    public void saveInTxt (String fac,String ID, String loc,String barcode,String scount) throws IOException {
        File saveFile = new File(getFilesDir().getPath() + "/stockopname"); // 저장 경로
        long now = System.currentTimeMillis(); // 현재시간 받아오기
        Date date = new Date(now); // Date 객체 생성
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String nowTime = sdf.format(date);

        File txtFile = new File(saveFile.getAbsolutePath()+"/"+intent_factory+"_"+intent_location+"_"+intent_id+"_"+nowDate+".txt");
// 폴더 생성
        if(!saveFile.exists()){ // 폴더 없을 경우
            saveFile.mkdir(); // 폴더 생성
        }

        if(!txtFile.exists()){
            txtFile.createNewFile();
        }
        try {
            BufferedWriter buf = new BufferedWriter(new FileWriter(txtFile, true));
            buf.append(fac+","); //사업부 0
            buf.append(ID+","); //사번 1
            buf.append(loc+","); //위치 2
            buf.append(barcode+","); // 바코드 3
            buf.append(nowTime+","); // 날짜 쓰기 4
            buf.append(scount); //NO count 5
            buf.newLine(); // 개행
            buf.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void readTxt() throws IOException {
        String line = null; // 한줄씩 읽기
        File saveFile = new File(getFilesDir().getPath() + "/stockopname"); // 저장 경로
        long now = System.currentTimeMillis(); // 현재시간 받아오기
        Date date = new Date(now); // Date 객체 생성
        SimpleDateFormat sdf_date = new SimpleDateFormat("MMdd");
        String nowDate = sdf_date.format(date);
        File txtFile = new File(saveFile.getAbsolutePath()+"/"+intent_factory+"_"+intent_location+"_"+intent_id+"_"+nowDate+".txt");
        // 폴더 생성
        if(!saveFile.exists()){ // 폴더 없을 경우
            saveFile.mkdir(); // 폴더 생성
        }
        if(!txtFile.exists()){
            txtFile.createNewFile();
        }
        try {


            BufferedReader buf = new BufferedReader(new FileReader(txtFile));
            ArrayList<String> data_fac = new ArrayList<String>();
            ArrayList<String> data_id = new ArrayList<String>();
            ArrayList<String> data_loc = new ArrayList<String>();
            ArrayList<String> data_barcode = new ArrayList<String>();
            ArrayList<String> data_time = new ArrayList<String>();
            ArrayList<String> data_count = new ArrayList<String>();

            while((line=buf.readLine())!=null){
                String[] txt_data = line.split(",");
                data_fac.add(txt_data[0]);
                data_id.add(txt_data[1]);
                data_loc.add(txt_data[2]);
                data_barcode.add(txt_data[3]);
                String[] txt_data_time = txt_data[4].split("\\s+");
                data_time.add(txt_data_time[1]);
                data_count.add(txt_data[5]);
                setCount(Math.max(getCount(),Integer.valueOf(txt_data[5])));
            }
            Collections.reverse(data_fac);
            Collections.reverse(data_id);
            Collections.reverse(data_loc);
            Collections.reverse(data_barcode);
            Collections.reverse(data_time);
            Collections.reverse(data_count);
            appendRow(data_count,data_barcode,data_time);
            buf.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }


    public void appendRow(ArrayList<String> data_count,ArrayList<String> data_barcode,ArrayList<String> data_time){
        TableLayout tb = findViewById(R.id.scan_table);
        tb.removeAllViewsInLayout();
        //TableRow row = (TableRow) findViewById(R.id.Body_Row);

        // TextView count = (TextView)row.findViewById(R.id.Body_Count);
        // count.setText("1");
        //  TextView barcode = (TextView)row.findViewById(R.id.Body_Barcode);
        //  arcode.setText(strarray[3]);
        // TextView time = (TextView)row.findViewById(R.id.Body_Time);
        // time.setText(strarray[4]);
        TextView[] tv = new TextView[data_count.size()];

        for(int i=0;i<data_count.size();i++) {
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams( LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT ));

            TextView tv1 = new TextView(this);
            tv1.setText(data_count.get(i));
            tv1.setTextColor(Color.parseColor("#111111"));
            tv1.setBackgroundResource(R.drawable.border);
            tv1.setGravity(Gravity.CENTER);
            tv1.setShadowLayer(1.0f, 1, 1, Color.parseColor("#AFFFFFFF"));

            TextView tv2 = new TextView(this);
            tv2.setText(data_barcode.get(i));
            tv2.setTextColor(Color.parseColor("#111111"));
            tv2.setBackgroundResource(R.drawable.border);
            tv2.setGravity(Gravity.CENTER);
            tv2.setShadowLayer(1.0f, 1, 1, Color.parseColor("#AFFFFFFF"));

            TextView tv3 = new TextView(this);
            tv3.setText(data_time.get(i));
            tv3.setTextColor(Color.parseColor("#111111"));
            tv3.setBackgroundResource(R.drawable.border);
            tv3.setGravity(Gravity.CENTER);
            tv3.setShadowLayer(1.0f, 1, 1, Color.parseColor("#AFFFFFFF"));

            row.addView(tv1, new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,1));
            row.addView(tv2, new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,5));
            row.addView(tv3, new TableRow.LayoutParams(0, LayoutParams.WRAP_CONTENT,2));
            tb.addView(row,new TableLayout.LayoutParams( LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        }
        etBarcode.requestFocus();
    }
}



